// AuthContext — global auth state: Google, email/password, phone OTP, anonymous
import React, { createContext, useContext, useEffect, useState } from 'react';
import {
    onAuthStateChanged,
    signInWithPopup,
    signInWithRedirect,
    signInWithCredential,
    getRedirectResult,
    GoogleAuthProvider,
    signOut,
    signInAnonymously,
    createUserWithEmailAndPassword,
    signInWithEmailAndPassword,
    sendPasswordResetEmail,
    sendEmailVerification,
    RecaptchaVerifier,
    signInWithPhoneNumber,
    setPersistence,
    browserLocalPersistence,
    indexedDBLocalPersistence
} from 'firebase/auth';
import { auth, db } from '../services/firebase';
import { doc, setDoc, getDoc, addDoc, collection, onSnapshot, updateDoc, serverTimestamp, arrayUnion } from 'firebase/firestore';
import { Capacitor } from '@capacitor/core';
import ComplianceModal from '../components/auth/ComplianceModal';
import { initFCM } from '../services/fcmService';

const TERMS_VERSION = 2;
const APP_VERSION = '2026-03-20-S1'; // Version bump for stability fix
window.__SOUL_AUTH_VER__ = APP_VERSION;

const AuthContext = createContext();

export function useAuth() {
    return useContext(AuthContext);
}

export function AuthProvider({ children }) {
    const [currentUser, setCurrentUser] = useState(() => {
        try {
            const cached = localStorage.getItem('soul_user_cache');
            if (!cached) return null;
            const parsed = JSON.parse(cached);
            return parsed.uid ? parsed : null;
        } catch (e) {
            localStorage.removeItem('soul_user_cache');
            return null;
        }
    });
    const [loading, setLoading] = useState(true);
    const [confirmationResult, setConfirmationResult] = useState(null);
    const [showCompliance, setShowCompliance] = useState(false);
    
    // Check st_uid for immediate unblock
    const [authInitialized, setAuthInitialized] = useState(() => {
        return !!localStorage.getItem('st_uid');
    });

    // Detect Credential Manager support on mount synchronously
    useEffect(() => {
        if (!localStorage.getItem('st_cm_supported')) {
            const isAndroid = Capacitor.getPlatform() === 'android';
            // Credential Manager is typically supported on Android 14+ (API 34+). 
            // For simplicity in synchronous detection, we mark it true for modern Android versions or fallbacks.
            // If the first call fails with a non-cancel error, we will flip this flag.
            localStorage.setItem('st_cm_supported', isAndroid ? 'true' : 'false');
        }
    }, []);

    // Persistence: Save only essential serializable user data
    useEffect(() => {
        if (currentUser && currentUser.uid) {
            const safeData = {
                uid: currentUser.uid,
                email: currentUser.email,
                displayName: currentUser.displayName,
                photoURL: currentUser.photoURL,
                role: currentUser.role,
                isAdmin: currentUser.isAdmin,
                isOwner: currentUser.isOwner,
                acceptedVersion: currentUser.acceptedVersion
            };
            localStorage.setItem('soul_user_cache', JSON.stringify(safeData));
            localStorage.setItem('st_uid', currentUser.uid);
        } else if (currentUser === null && authInitialized) {
            localStorage.removeItem('soul_user_cache');
            localStorage.removeItem('st_uid');
        }
    }, [currentUser, authInitialized]);

    // ── Phone Auth: Step 1 – Send OTP ──────────────────────────────────────
    async function sendOTP(phoneNumber, recaptchaContainerId) {
        const isNative = typeof window !== 'undefined' &&
            (Capacitor.isNativePlatform() ||
                window.location.protocol === 'capacitor:' ||
                window.location.protocol === 'ionic:');

        try {
            if (isNative) {
                // Triggering native phone OTP flow
                const { FirebaseAuthentication } = await import('@capacitor-firebase/authentication');

                return new Promise((resolve, reject) => {
                    let resolved = false;
                    let listenerCodeSentPromise;
                    let listenerFailedPromise;

                    const cleanup = async () => {
                        try {
                            const codeSentHandle = await listenerCodeSentPromise;
                            if (codeSentHandle) codeSentHandle.remove();
                            const failedHandle = await listenerFailedPromise;
                            if (failedHandle) failedHandle.remove();
                        } catch (e) { }
                    };

                    listenerCodeSentPromise = FirebaseAuthentication.addListener('phoneCodeSent', (event) => {
                        // Native phone code sent
                        setConfirmationResult({ isNative: true, verificationId: event.verificationId });
                        if (!resolved) {
                            resolved = true;
                            cleanup();
                            resolve({ isNative: true, verificationId: event.verificationId });
                        }
                    });

                    listenerFailedPromise = FirebaseAuthentication.addListener('phoneVerificationFailed', (event) => {
                        console.error('❌ Native phone verification failed:', event.message);
                        if (!resolved) {
                            resolved = true;
                            cleanup();
                            reject(new Error(event.message));
                        }
                    });

                    FirebaseAuthentication.signInWithPhoneNumber({
                        phoneNumber,
                        skipNativeAuth: false
                    }).catch(error => {
                        console.error('❌ Native sign in failed', error);
                        if (!resolved) {
                            resolved = true;
                            cleanup();
                            reject(error);
                        }
                    });
                });
            } else {
                if (window.recaptchaVerifier) {
                    window.recaptchaVerifier.clear();
                    window.recaptchaVerifier = null;
                }
                window.recaptchaVerifier = new RecaptchaVerifier(auth, recaptchaContainerId, {
                    size: 'invisible',
                    callback: () => { }
                });
                const result = await signInWithPhoneNumber(auth, phoneNumber, window.recaptchaVerifier);
                setConfirmationResult(result);
                return result;
            }
        } catch (error) {
            console.error('Send OTP failed:', error);
            throw error;
        }
    }

    // ── Phone Auth: Step 2 – Verify OTP ───────────────────────────────────
    async function verifyOTP(otp) {
        if (!confirmationResult) throw new Error('No OTP session. Please request OTP first.');

        const isNative = typeof window !== 'undefined' &&
            (Capacitor.isNativePlatform() ||
                window.location.protocol === 'capacitor:' ||
                window.location.protocol === 'ionic:');

        try {
            let user;
            if (isNative && confirmationResult.isNative) {
                const { PhoneAuthProvider, signInWithCredential } = await import('firebase/auth');
                const { FirebaseAuthentication } = await import('@capacitor-firebase/authentication');

                await FirebaseAuthentication.confirmVerificationCode({
                    verificationId: confirmationResult.verificationId,
                    verificationCode: otp
                });

                const credential = PhoneAuthProvider.credential(confirmationResult.verificationId, otp);
                const userCredential = await signInWithCredential(auth, credential);
                user = userCredential.user;
            } else {
                const result = await confirmationResult.confirm(otp);
                user = result.user;
            }

            const userRef = doc(db, 'users', user.uid);
            const userSnap = await getDoc(userRef);
            return { user, isNewUser: !userSnap.exists() };
        } catch (error) {
            console.error('Verify OTP failed:', error);
            throw error;
        }
    }

    async function createPhoneUserProfile(user, profileData) {
        const userRef = doc(db, 'users', user.uid);
        await setDoc(userRef, {
            uid: user.uid,
            displayName: profileData.name,
            phoneNumber: user.phoneNumber,
            age: profileData.age || null,
            gender: profileData.gender || null,
            bio: profileData.bio || '',
            interests: profileData.interests || [],
            categoryEngagementStats: {},
            photoURL: `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.uid}`,
            role: 'user',
            isAdmin: false,
            createdAt: new Date().toISOString()
        });
        try {
            await addDoc(collection(db, 'admin_notifications'), {
                type: 'NEW_USER_phone',
                message: `New user via phone: ${profileData.name} (${user.phoneNumber})`,
                createdAt: new Date().toISOString(),
                readBy: []
            });
        } catch (e) { }

        // Redirect new phone users to onboarding
        window.location.assign('/onboarding');
        return new Promise(() => {});
    }

    function resetPassword(email) {
        return sendPasswordResetEmail(auth, email);
    }

    async function loginWithGoogle() {
        const isNative = typeof window !== 'undefined' &&
            (Capacitor.isNativePlatform() ||
                window.location.protocol === 'capacitor:' ||
                window.location.protocol === 'ionic:');

        try {
            if (isNative) {
                const { FirebaseAuthentication } = await import('@capacitor-firebase/authentication');
                const webClientId = "813685915255-h8ajgn54lvgp0opp12h74e9b2skq93ei.apps.googleusercontent.com";

                let result;
                const cmKey = 'st_cm_ok';
                const useCM = localStorage.getItem(cmKey) !== 'false';

                try {
                    result = await FirebaseAuthentication.signInWithGoogle({
                        scopes: ["email", "profile"],
                        webClientId: webClientId,
                        grantOfflineAccess: true,
                        useCredentialManager: useCM
                    });
                    localStorage.setItem(cmKey, 'true'); // CM worked, remember it
                } catch (credError) {
                    if (useCM) {
                        localStorage.setItem(cmKey, 'false'); // CM failed, skip next time
                        result = await FirebaseAuthentication.signInWithGoogle({
                            scopes: ["email", "profile"],
                            webClientId: webClientId,
                            grantOfflineAccess: true,
                            useCredentialManager: false
                        });
                    } else {
                        throw credError;
                    }
                }

                if (!result?.credential?.idToken) {
                    throw new Error("Google identity token missing.");
                }

                const credential = GoogleAuthProvider.credential(result.credential.idToken);
                const finalResult = await signInWithCredential(auth, credential);
                _saveGoogleUserProfile(finalResult.user).catch(e =>
                    console.warn('Profile save after Google login failed (non-critical):', e)
                );
                return finalResult;
            } else {
                // Use popup — signInWithRedirect is broken in modern browsers
                // due to third-party cookie restrictions (Safari, Chrome, Firefox).
                const provider = new GoogleAuthProvider();
                provider.addScope('email');
                provider.addScope('profile');
                provider.setCustomParameters({ prompt: 'select_account' });

                try {
                    const result = await signInWithPopup(auth, provider);
                    // Save profile in background — must NOT block or throw into the auth flow
                    _saveGoogleUserProfile(result.user).catch(e =>
                        console.warn('Profile save after Google login failed (non-critical):', e)
                    );
                    return result;
                } catch (popupError) {
                    // Popup closed by user — silent, nothing to do
                    if (popupError.code === 'auth/popup-closed-by-user') {
                        return;
                    }
                    // Popup was blocked — fall back to redirect
                    if (popupError.code === 'auth/popup-blocked') {
                        await signInWithRedirect(auth, provider);
                        return;
                    }
                    throw popupError;
                }
            }
        } catch (error) {
            console.error("❌ Google Login failed:", error);
            throw error;
        }
    }

    async function _saveGoogleUserProfile(user) {
        if (!user) return;
        const userRef = doc(db, "users", user.uid);
        const userSnap = await getDoc(userRef);
        const adminEmails = ['rupesh2510@gmail.com', 'anchalmaurya406@gmail.com', 'bhavyajha.bhu@gmail.com'];
        const isAdmin = adminEmails.includes(user.email?.toLowerCase());
        
        if (!userSnap.exists()) {
            const random4 = Math.random().toString(36).substring(2, 6).toUpperCase();
            await setDoc(userRef, {
                uid: user.uid,
                displayName: user.displayName || 'Soul Searcher',
                email: user.email,
                anonymousHandle: `Soul${random4}`,
                photoURL: user.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.uid}`,
                role: isAdmin ? 'admin' : 'user',
                isAdmin: isAdmin,
                createdAt: new Date().toISOString()
            });
            // Redirect new google users to onboarding ONLY in the User App
            if (!document.title.includes('SoulThread Pro')) {
                window.location.assign('/onboarding');
                return new Promise(() => {});
            }
        } else if (isAdmin && userSnap.data().role !== 'admin') {
            await updateDoc(userRef, { role: 'admin', isAdmin: true });
        }
    }

    async function loginAnonymously() {
        try {
            const result = await signInAnonymously(auth);
            const userRef = doc(db, "users", result.user.uid);
            const userSnap = await getDoc(userRef);
            if (!userSnap.exists()) {
                await setDoc(userRef, {
                    uid: result.user.uid,
                    displayName: "Anonymous Soul",
                    photoURL: `https://api.dicebear.com/7.x/avataaars/svg?seed=${result.user.uid}`,
                    role: 'user',
                    isAnonymous: true,
                    createdAt: new Date().toISOString()
                });
            }
            return result;
        } catch (error) {
            console.error("Anonymous login failed", error);
            throw error;
        }
    }

    async function signup(email, password, displayName, extras = {}) {
        try {
            const result = await createUserWithEmailAndPassword(auth, email.trim(), password);
            const adminEmails = ['rupesh2510@gmail.com', 'anchalmaurya406@gmail.com', 'bhavyajha.bhu@gmail.com'];
            const isAdmin = adminEmails.includes(email.toLowerCase());

            await setDoc(doc(db, "users", result.user.uid), {
                uid: result.user.uid,
                email: email,
                displayName: displayName,
                anonymousHandle: extras.anonymousHandle || `Soul${result.user.uid.slice(-4)}`,
                profession: extras.profession || '',
                place: extras.place || '',
                gender: extras.gender || '',
                photoURL: `https://api.dicebear.com/7.x/avataaars/svg?seed=${result.user.uid}`,
                role: isAdmin ? 'admin' : 'user',
                isAdmin: isAdmin,
                createdAt: new Date().toISOString()
            });

            try {
                await sendEmailVerification(result.user);
            } catch (e) { }

            // Redirect new email users to onboarding
            window.location.assign('/onboarding');
            return new Promise(() => {});
        } catch (error) {
            console.error("Signup failed", error);
            throw error;
        }
    }

    async function login(email, password) {
        return signInWithEmailAndPassword(auth, email.trim(), password);
    }

    async function logout() {
        localStorage.removeItem('soul_user_cache');
        localStorage.removeItem('st_uid');
        
        const isNative = typeof window !== 'undefined' &&
            (Capacitor.isNativePlatform() ||
                window.location.protocol === 'capacitor:' ||
                window.location.protocol === 'ionic:');
                
        if (isNative) {
            try {
                const { FirebaseAuthentication } = await import('@capacitor-firebase/authentication');
                await FirebaseAuthentication.signOut();
            } catch (e) {
                console.error('Native sign-out error:', e);
            }
        }
        
        return signOut(auth);
    }

    async function requestFCMToken(userId) {
        // Wait briefly so as not to block UI loading, then init native/web push notifications
        setTimeout(() => {
            initFCM(userId).catch(e => console.warn('FCM init warning:', e));
        }, 5000);
    }

    useEffect(() => {
        if (window.logToScreen) window.logToScreen('[4] AuthContext useEffect start');
        const isNative = Capacitor.isNativePlatform();
        
        // Safety timeout to prevent infinite splash screen hang
        const initTimeout = setTimeout(() => {
            if (loading && !authInitialized) {
                console.warn("Auth initialization timeout - unblocking UI");
                if (window.logToScreen) window.logToScreen('[5] Auth timeout triggered');
                setLoading(false);
                setAuthInitialized(true);
            }
        }, 200);

        const initializeAuthSystem = async () => {
            try {
                const persistenceType = (isNative || !('indexedDB' in window)) 
                    ? indexedDBLocalPersistence 
                    : browserLocalPersistence;
                
                await setPersistence(auth, persistenceType);

                if (!isNative) {
                    const result = await getRedirectResult(auth);
                    if (result?.user) {
                        await _saveGoogleUserProfile(result.user);
                    }
                }
            } catch (err) {
                console.error("Auth Init Error:", err);
            }
        };

        initializeAuthSystem();

        let unsubUserDoc = null;

        const unsubscribeAuth = onAuthStateChanged(auth, async (user) => {
            if (unsubUserDoc) {
                unsubUserDoc();
                unsubUserDoc = null;
            }

            if (user) {
                // Render immediately with the Auth profile Firebase already gave us —
                // no need to wait on a Firestore round-trip just to unblock the UI.
                clearTimeout(initTimeout);
                setCurrentUser(prev => (prev && prev.uid === user.uid) ? prev : user);
                if (window.logToScreen) window.logToScreen('[6] onAuthStateChanged user loaded');
                setLoading(false);
                setAuthInitialized(true);

                const userRef = doc(db, 'users', user.uid);

                unsubUserDoc = onSnapshot(userRef, (docSnap) => {
                    if (docSnap.exists()) {
                        const userData = docSnap.data();
                        setCurrentUser(prev => ({
                            ...(prev || {}),
                            ...userData,
                            uid: user.uid,
                            email: user.email,
                            photoURL: userData.photoURL || user.photoURL
                        }));
                        setShowCompliance(!userData.acceptedVersion || userData.acceptedVersion < TERMS_VERSION);
                    }
                }, (err) => {
                    console.error("Profile Snapshot Error:", err);
                });

                requestFCMToken(user.uid);
            } else {
                clearTimeout(initTimeout);
                setCurrentUser(null);
                if (window.logToScreen) window.logToScreen('[7] onAuthStateChanged user null');
                setLoading(false);
                setAuthInitialized(true);
            }
        });

        return () => {
            unsubscribeAuth();
            if (unsubUserDoc) unsubUserDoc();
            clearTimeout(initTimeout);
        };
    }, []);

    const value = React.useMemo(() => ({
        currentUser,
        loginWithGoogle,
        loginAnonymously,
        signup,
        login,
        logout,
        resetPassword,
        sendOTP,
        verifyOTP,
        createPhoneUserProfile,
        loading: loading && !authInitialized
    }), [currentUser, loading, authInitialized, confirmationResult]);

    if (loading && !authInitialized && !currentUser) {
        const steps = ['Opening your sanctuary', 'Checking your session', 'Almost there'];
        return (
            <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center',
                alignItems: 'center', height: '100vh', background: 'var(--color-background)', gap: '16px' }}>
                <div style={{ width: '40px', height: '40px', borderRadius: '50%',
                    border: '3px solid var(--color-primary-soft)', borderTopColor: 'var(--color-primary)',
                    animation: 'spin 0.8s linear infinite' }} />
                <span style={{ fontFamily: 'Outfit, sans-serif', color: 'var(--color-text-secondary)',
                    fontSize: '13px', letterSpacing: '0.03em' }}>
                    Setting up your space...
                </span>
                <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
            </div>
        );
    }

    return (
        <AuthContext.Provider value={value}>
            {showCompliance && currentUser && (
                <ComplianceModal
                    user={currentUser}
                    termsVersion={TERMS_VERSION}
                    onAccept={() => setShowCompliance(false)}
                />
            )}
            {children}
        </AuthContext.Provider>
    );
}
