import { BaseRepository } from './BaseRepository';
import { limit } from 'firebase/firestore';

class GuideRepositoryImpl extends BaseRepository {
  constructor() {
    super('guides');
  }

  /**
   * Fetches verified guides up to a limit.
   * @param {number} limitCount 
   * @returns {Promise<Array>}
   */
  async getVerifiedGuides(limitCount = 50) {
    // In production, add where('isVerified', '==', true)
    return this.findMany([
      limit(limitCount)
    ]);
  }
}

export const GuideRepository = new GuideRepositoryImpl();
