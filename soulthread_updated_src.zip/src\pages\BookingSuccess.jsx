import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '../services/firebase';
import { useAuth } from '../contexts/AuthContext';
import DesktopLayoutWrapper from '../components/layout/DesktopLayoutWrapper';
import SEO from '../components/common/SEO';
import { CheckCircle2, Calendar as CalendarIcon, Video, Download, ArrowRight, UserPlus, X, Heart, Clock, Mail, ShieldAlert } from 'lucide-react';
import { Card } from '../components/common/Card';
import { Button } from '../components/common/Button';

export default function BookingSuccess() {
    const { psychologistId } = useParams();
    const navigate = useNavigate();
    const { currentUser } = useAuth();
    const [guide, setGuide] = useState(null);
    const [showAccountPrompt, setShowAccountPrompt] = useState(!currentUser);

    useEffect(() => {
        const fetchGuide = async () => {
            const docRef = doc(db, 'guides', psychologistId);
            const docSnap = await getDoc(docRef);
            if (docSnap.exists()) setGuide(docSnap.data());
        };
        fetchGuide();
    }, [psychologistId]);

    return (
        <DesktopLayoutWrapper>
            <SEO title="Session Confirmed | SoulThread" />
            
            <div className="min-h-screen bg-[#fafafa] flex flex-col items-center justify-center p-4 py-12">
                <Card premium className="max-w-2xl w-full p-8 md:p-12 text-center relative overflow-hidden">
                    
                    {/* Calming Header */}
                    <div className="w-20 h-20 bg-green-50 rounded-full flex items-center justify-center mx-auto mb-6">
                        <Heart className="w-10 h-10 text-green-600" />
                    </div>

                    <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-3">You're all set. We'll be here for you.</h1>
                    <p className="text-gray-500 mb-10 text-lg max-w-md mx-auto">Take a deep breath. Your session has been successfully scheduled and we've emailed you the details.</p>

                    {/* Appointment Summary */}
                    {guide && (
                        <div className="bg-gray-50/50 border border-gray-200 rounded-2xl p-6 mb-10 text-left shadow-sm">
                            <div className="flex items-center gap-4 mb-4 pb-4 border-b border-gray-200">
                                {guide.photoURL ? (
                                    <img src={guide.photoURL} alt={guide.name} className="w-14 h-14 rounded-full border border-gray-200 object-cover shadow-sm" />
                                ) : (
                                    <div className="w-14 h-14 rounded-full bg-gray-200 flex items-center justify-center font-bold text-gray-500 shadow-sm">{guide.name?.[0]}</div>
                                )}
                                <div>
                                    <p className="font-bold text-gray-900 text-lg">{guide.name}</p>
                                    <p className="text-sm text-gray-500">{guide.title || 'Clinical Psychologist'}</p>
                                </div>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div className="flex items-start gap-3">
                                    <CalendarIcon className="w-5 h-5 text-gray-400 shrink-0 mt-0.5" />
                                    <div>
                                        <p className="text-sm font-semibold text-gray-900">Date & Time</p>
                                        <p className="text-sm text-gray-600">Tomorrow at 10:30 AM (IST)</p>
                                    </div>
                                </div>
                                <div className="flex items-start gap-3">
                                    <Video className="w-5 h-5 text-gray-400 shrink-0 mt-0.5" />
                                    <div>
                                        <p className="text-sm font-semibold text-gray-900">Consultation Mode</p>
                                        <p className="text-sm text-gray-600">Video (Link sent 15 mins prior)</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}

                    {/* What Happens Next Timeline */}
                    <div className="mb-10 text-left border-l-2 border-gray-100 ml-3 pl-6 space-y-6">
                        <div className="relative">
                            <div className="absolute -left-[31px] bg-green-500 w-3 h-3 rounded-full ring-4 ring-white"></div>
                            <h4 className="font-semibold text-gray-900 text-sm">Booking Confirmed</h4>
                            <p className="text-xs text-gray-500 mt-1">You will receive a confirmation email shortly.</p>
                        </div>
                        <div className="relative">
                            <div className="absolute -left-[31px] bg-gray-300 w-3 h-3 rounded-full ring-4 ring-white"></div>
                            <h4 className="font-semibold text-gray-900 text-sm">Reminder Before Session</h4>
                            <p className="text-xs text-gray-500 mt-1">We'll send a gentle reminder 24 hours and 15 minutes before.</p>
                        </div>
                        <div className="relative">
                            <div className="absolute -left-[31px] bg-gray-300 w-3 h-3 rounded-full ring-4 ring-white"></div>
                            <h4 className="font-semibold text-gray-900 text-sm">Join Session</h4>
                            <p className="text-xs text-gray-500 mt-1">Click the secure link in your email to join the video call.</p>
                        </div>
                    </div>

                    {/* Preparation Guidance */}
                    <div className="bg-blue-50 border border-blue-100 rounded-2xl p-6 mb-8 text-left">
                        <h4 className="font-semibold text-blue-900 mb-3 text-sm uppercase tracking-wider">How to prepare</h4>
                        <ul className="text-sm text-blue-800 space-y-2 list-disc list-inside">
                            <li>Find a quiet, private space where you feel comfortable.</li>
                            <li>Join 5 minutes early to test your internet connection.</li>
                            <li>Keep a glass of water nearby.</li>
                            <li>There's no pressure—just bring yourself as you are.</li>
                        </ul>
                    </div>


                    {/* Quick Actions */}
                    <div className="space-y-4 mb-10">
                        <Button variant="primary" style={{ width: '100%' }}>
                            Add to Google Calendar
                        </Button>
                        <div className="flex flex-col sm:flex-row gap-3">
                            <Button variant="outline" style={{ flex: 1 }}>
                                Download Receipt
                            </Button>
                            <Button variant="secondary" onClick={() => navigate(currentUser ? '/' : '/experts')} style={{ flex: 1 }}>
                                {currentUser ? 'Go to Dashboard' : 'Explore Community'}
                            </Button>
                        </div>
                    </div>
                    
                    {/* Guest Account Prompt */}
                    {showAccountPrompt && (
                        <div className="bg-gray-900 rounded-2xl p-6 text-left relative text-white">
                            <button onClick={() => setShowAccountPrompt(false)} className="absolute top-4 right-4 text-gray-400 hover:text-white transition-colors">
                                <X className="w-5 h-5" />
                            </button>
                            <div className="flex items-center gap-3 mb-3">
                                <div className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center">
                                    <UserPlus className="w-5 h-5 text-gray-300" />
                                </div>
                                <h3 className="text-lg font-bold">Continue your healing journey</h3>
                            </div>
                            <p className="text-sm text-gray-300 mb-5 leading-relaxed pr-6">
                                Create a free SoulThread account to track this appointment, access your clinical notes, and manage future bookings seamlessly.
                            </p>
                            <div className="flex flex-col sm:flex-row gap-3">
                                <button onClick={() => navigate('/signup')} className="flex-1 py-3 bg-white text-black rounded-xl font-bold hover:bg-gray-100 transition-colors text-center">
                                    Create Free Account
                                </button>
                            </div>
                        </div>
                    )}

                    {/* Support Block */}
                    <div className="mt-12 pt-8 border-t border-gray-100 text-center">
                        <p className="text-sm text-gray-500 mb-2">Need to reschedule or ask a question?</p>
                        <div className="flex justify-center gap-6">
                            <a href="mailto:support@soulthread.in" className="flex items-center text-sm font-medium text-gray-900 hover:text-blue-600">
                                <Mail className="w-4 h-4 mr-1.5" /> Contact Support
                            </a>
                        </div>
                    </div>

                </Card>
            </div>
        </DesktopLayoutWrapper>
    );
}
